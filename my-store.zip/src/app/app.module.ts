import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { FormsModule } from '@angular/forms';
import { DemoComponent } from './demo/demo.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ReviewComponent } from './review/review.component';
import { OrderComponent } from './order/order.component';
import { verifyIdGuardGuard } from './verify-id-guard.guard';

const routes: Routes = [
  { path: "", component: HomeComponent, title: "MyStore | Home" },
  { path: "products", component: ProductListComponent, title: "MyStore | Products" },
  { path: "profile", component: ProfileComponent, title: "MyStore | Profile" },
  { path: "products/:id", component: ProductDetailsComponent, title: "MyStore | Details",
    canActivate: [verifyIdGuardGuard],
    children: [
      { path: "review", component: ReviewComponent, title: "MyStore | Review" },
      { path: "order", component:OrderComponent, title: "MyStore | Order" }
    ]
   },

  { path: "**", component: PagenotfoundComponent, title: "MyStore | Page Not Found" }
]

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    DemoComponent,
    NavbarComponent,
    HomeComponent,
    ProfileComponent,
    PagenotfoundComponent,
    ProductDetailsComponent,
    ReviewComponent,
    OrderComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
