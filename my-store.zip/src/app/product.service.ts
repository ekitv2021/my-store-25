import { Injectable } from '@angular/core';
import { Product } from './product';
import { BehaviorSubject, Observable, Subject, catchError, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  apiUrl = "http://localhost:3000"

  cartCountCommon: number = 0;

  cartCount$ = new BehaviorSubject<number>(0);

  increment(){
    this.cartCountCommon++; 
    //++ operator is used to increment the value of the variable by one
    this.cartCount$.next(this.cartCountCommon);
  }  

  //Read All
  //get method of the HttpClient
  getAllProducts(): Observable<Product[]>{
    return this.http.get<Product[]>(`${this.apiUrl}/products`)
                    .pipe(catchError((error: HttpErrorResponse) => {
                      //this throwError will send the error notification to the 
                      //subsciber
                      return throwError("Error occured while fetching the data");
                    }));
  }

  //get method for retreiving single product
  getProductById(id: number):Observable<Product>{
    return this.http.get<Product>(`${this.apiUrl}/products/${id}`);
  }
}
